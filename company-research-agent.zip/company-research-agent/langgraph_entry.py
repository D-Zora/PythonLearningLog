# langgraph_entry.py
# 用于编译图形流程或任务图
from backend.graph import Graph

# 编译图形流程或任务图
graph = Graph().compile()